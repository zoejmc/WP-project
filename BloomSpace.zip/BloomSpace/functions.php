<?php
// Navigation
function custom_theme_setup(){
    register_nav_menus( array(
        'header' => 'Header menu',
        'footer' => 'Footer menu'
    ));
}
add_action( 'after_setup_theme', 'custom_theme_setup');

// Add featured image support for posts
add_theme_support( 'post-thumbnails' );

// Register Custom Post Type - Plant Care Tips
function custom_register_plant_care_tips_post_type() {

    $labels = array(
        'name'                  => __( 'Plant Care Tips', 'Post Type General Name', 'text_domain' ),
        
    );
    $args = array(
        'label'                 => __( 'Plant Care Tip', 'text_domain' ),
        'description'           => __( 'Plant Care Tips Description', 'text_domain' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions', 'page-attributes' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
        'show_in_rest'          => true,
    );
    register_post_type( 'plant_care_tip', $args );

}
add_action( 'init', 'custom_register_plant_care_tips_post_type', 0 );

// Shortcode to display plant care tips list
function custom_plant_care_tips_shortcode() {
    $args = array(
        'post_type'      => 'plant_care_tip',
        'posts_per_page' => 5, 
    );

    $query = new WP_Query( $args );

    if ( $query->have_posts() ) {
        $output = '<ul>';
        while ( $query->have_posts() ) {
            $query->the_post();
            $output .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
        }
        $output .= '</ul>';
    } else {
        $output = 'No plant care tips found.';
    }

    wp_reset_postdata();

    return $output;
}
add_shortcode( 'plant_care_tips', 'custom_plant_care_tips_shortcode' );
?>
