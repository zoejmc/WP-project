<?php

/**
 * Template Name: Homepage Advanced Custom Fields
 * Template Post Type: page
 */
get_header();
?>
<main>
    <section class="masthead" style="background-image: url('<?php the_field('masthead_image'); ?>');">
        <div class="banner-box">
            <h1 class="main-title"><?php the_field('page_title'); ?></h1>
            <h1 class="sub-title"><?php the_field('sub_title'); ?></h1>
        </div>
    </section>
    
    <div class="container">
    <div class="featured-product-title">
            <div class="col-md-12">
                <h2><?php the_field('featured_product_title'); ?></h2>
            </div>
        </div>
        
        <div class="row">
        <?php
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 4, // Adjust the number of products to display
    'tax_query'      => array(
        array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => 'featured-products', 
        ),
    ),
);
$featured_products = new WP_Query($args);

if ($featured_products->have_posts()) :
    while ($featured_products->have_posts()) : $featured_products->the_post();
        global $product;
?>
        <div class="col-md-3">
            <a href="<?php the_permalink(); ?>" class="product-link">
                <div class="card custom-bg-color2">
                    <div class="card-body">
                        <div class="icon-container">
                            <?php
                            if (has_post_thumbnail()) {
                                echo get_the_post_thumbnail($product->get_id(), 'thumbnail');
                            } else {
                                echo '<img src="' . wc_placeholder_img_src() . '" alt="Placeholder" />';
                            }
                            ?>
                        </div>
                        <h2><?php the_title(); ?></h2>
                        <p><?php echo $product->get_price_html(); ?></p>
                    </div>
                </div>
            </a>
        </div>
<?php
    endwhile;
    wp_reset_postdata();
else :
    echo 'No featured products found';
endif;
?>
            <div class="col-md-3">
                <div class="card custom-bg-color">
                    <div class="card-body">
                        <div class="icon-container">
                            <i class="bi bi-fingerprint"></i>
                        </div>
                        <h2><?php echo wp_kses_post(get_field('row_one_title')); ?></h2>
                        <p><?php echo wp_kses_post(get_field('row_one_text')); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card custom-bg-color2">
                    <div class="card-body">
                        <div class="icon-container">
                            <i class="bi bi-tree"></i>
                        </div>
                        <h2><?php echo wp_kses_post(get_field('row_two_title')); ?></h2>
                        <p><?php echo wp_kses_post(get_field('row_two_text')); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card custom-bg-color2">
                    <div class="card-body">
                    <div class="icon-container">
                            <i class="bi bi-truck"></i>
                        </div>
                        <h2><?php echo wp_kses_post(get_field('row_three_title')); ?></h2>
                        <p><?php echo wp_kses_post(get_field('row_three_text')); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card custom-bg-color2">
                    <div class="card-body">
                    <div class="icon-container">
                        <i class="bi bi-calendar2-heart"></i>
                    </div>
                        <h2><?php echo wp_kses_post(get_field('row_four_title')); ?></h2>
                        <p><?php echo wp_kses_post(get_field('row_four_text')); ?></p>
                    </div>
                </div>
            </div>


</main>

<?php
get_footer();
?>