<?php
/*
 * Template Name: Custom Single Product
 */

if (is_product(62)) {
    get_header(); // Include header template
    ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

            <?php
            while (have_posts()) :
                the_post();

                wc_get_template_part('content', 'single-product');

            endwhile; // End of the loop.
            ?>

        </main><!-- #main -->
    </div><!-- #primary -->

    <?php
    get_footer(); // Include footer template
} else {
    // If the product ID doesn't match, redirect to the product itself
    global $post;
    wp_redirect(get_permalink($post->ID));
    exit;
}
