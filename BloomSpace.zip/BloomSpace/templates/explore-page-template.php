<?php
/*
Template Name: Explore Page Template
*/

get_header();

// Query posts
$args = array(
    'post_type' => 'post', 
    'posts_per_page' => -1, // Display all posts
);

$posts_query = new WP_Query($args);

// Start the loop
if ($posts_query->have_posts()) :
    while ($posts_query->have_posts()) : $posts_query->the_post();
?>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <div class="entry-content">
            <?php the_content(); ?>
        </div>
        <?php
        // Check if the post has tags
        if (has_tag()) {
            echo '<div class="post-tags">';
            echo '<span>Tags:</span>';
            echo get_the_tag_list('<ul><li>', '</li><li>', '</li></ul>');
            echo '</div>';
        }
        ?>
    </article>
<?php
    endwhile;
    wp_reset_postdata();
else :
    echo 'No posts found.';
endif;

get_footer();
?>
