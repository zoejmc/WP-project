<footer class="footer mt-auto p-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <a href="<?php echo esc_url( home_url() ); ?>">
                        <img class="footer-logo" src="<?php echo esc_url( home_url( 'wp-content/uploads/2024/04/logo.png' ) ); ?>" alt="header logo">
                    </a>
            </div>
        </div>
    </div>
</footer>
</body>
</html>
